BadPlaner SHK V2 – FIXED TOUCH

Diese Version behebt das Einfügen:
1. „＋ ELEMENT EINFÜGEN“ antippen
2. Element auswählen
3. Es erscheint sofort im Grundriss
4. Antippen zum Auswählen
5. Finger halten und ziehen zum Verschieben
6. Drehen / Maße / Löschen über die Werkzeugleiste

Enthalten:
WC, Waschtisch, Dusche, Wanne, Badheizkörper, Möbel, Armatur,
Vorwand, Tür, Fenster sowie Geberit-GIS-WC, GIS-Waschtisch,
GIS-Dusche und GIS-Trennwand.

Für die installierbare PWA muss der Ordner über HTTPS bereitgestellt werden.
Auf iPhone Safari: Teilen -> Zum Home-Bildschirm.
